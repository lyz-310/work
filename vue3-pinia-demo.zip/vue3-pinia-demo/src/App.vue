<script setup>
import SonCom1 from './components/SonCom1.vue'
import SonCom2 from './components/SonCom2.vue'
import { userCountStore } from './store/counter'
import { userChannelStore } from './store/channel'
import { storeToRefs } from 'pinia'
const counterStore = userCountStore()
const channelStore = userChannelStore()
console.log(counterStore)
//    直接解构不处理会丢失数据响应式
const { count, msg } = storeToRefs(counterStore)
const { channelList } = storeToRefs(channelStore)
const { getList } = channelStore
</script>

<template>
  <h3>App.vue根组件 -- {{ counterStore.count }} -- {{ counterStore.msg }}</h3>
  <hr />
  {{ count }}----{{ msg }}
  <SonCom1></SonCom1>
  <SonCom2></SonCom2>
  <hr />
  <button @click="getList()">获取频道数据</button>
  <ul>
    <li v-for="item in channelList" :key="item.id">{{ item.name }}</li>
  </ul>
</template>

<style scoped></style>
