import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
//定义store
// defineStore(仓库的唯一标识, ()=>{...})
export const userCountStore = defineStore(
  'counter',
  () => {
    //可以声明数据 state -count
    const count = ref(0)
    //可以声明操作数据的方法 action
    const addCount = () => {
      count.value++
    }
    const subCount = () => {
      count.value--
    }
    //声明基于数据派生的计算属性 getter
    const double = computed(() => count.value * 2)
    //声明数据  state --msg
    const msg = ref('hello,pinia')

    return {
      count,
      msg,
      addCount,
      subCount,
      double
    }
  },
  {
    // persist: true
    //在第三个参数的位置加persist，进行持久化
    //开启当前模块的持久化
    //自定义密钥
    persist: {
      key: 'hm-count',
      paths: ['count']
      //存储的是哪些数据
    }
  }
)
