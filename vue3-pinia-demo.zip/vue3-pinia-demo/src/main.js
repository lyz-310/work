import { createApp } from 'vue'
import App from './App.vue'
import { createPinia } from 'pinia'
//导入持久化的插件
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate'
const pinia = createPinia() //创建pinia实例
createApp(App).use(pinia.use(piniaPluginPersistedstate)).mount('#app') //创建根实例，pinia插件的安装
//往pinia上进行挂载
