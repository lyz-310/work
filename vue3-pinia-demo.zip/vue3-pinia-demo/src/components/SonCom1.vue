<script setup>
import { userCountStore } from '@/store/counter'
const counterStore = userCountStore()
</script>

<template>
  <div>
    我是Son1 -- {{ counterStore.count }}<button @click="counterStore.addCount">+</button>
    <h4>{{ counterStore.double }}</h4>
  </div>
</template>

<style scoped></style>
