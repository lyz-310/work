<script setup>
import { userCountStore } from '@/store/counter'
const counterStore = userCountStore()
</script>

<template>
  <div>我是Son2 -- {{ counterStore.count }}<button @click="counterStore.subCount">-</button></div>
</template>

<style scoped></style>
