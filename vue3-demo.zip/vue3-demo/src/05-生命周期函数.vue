<script setup>
import { onMounted } from 'vue'

//beforeCreate 和 created 的相关代码
//一律放在setup中执行

const getList = () => {
  setTimeout(() => {
    console.log(666)
  }, 2000)
}
//一进入页面的请求
getList()

//如果有些代码需要在mounted生命周期中执行的
//mounted通常是在一些插件的使用或者组件的使用中进行操作 也就是页面渲染之后执行 通常情况下我们会在没有相应的点击事件，但需要在页面展示过程中去不断调用某一函数情况下使用。
onMounted(() => {
  console.log('Mounted生命周期函数逻辑一')
})
//写成函数的调用方式是可以调用多次的   并不会冲突，按照顺序进行执行
onMounted(() => {
  console.log('Mounted生命周期函数逻辑二')
})
</script>

<template>
  <div></div>
</template>
