<script setup>
import { ref, watch } from 'vue'
const count = ref(0)
const nikename = ref('张三')

const changeCount = () => {
  count.value++
}
const changeNikename = () => {
  nikename.value = '李四'
}

//1.监视单个数据的变化
// watch(ref对象, (newValue,OldValue) => {})
// watch(count, (newValue, OldValue) => {
//   console.log(newValue, OldValue)
// })

//2.监视多个数据的变化
// watch([count, nikename], (newArr, OldArr) => {})
watch([count, nikename], (newArr, oldArr) => {
  console.log(newArr, oldArr)
})

//3.immediate 立刻执行

watch(
  count,
  (newValue, OldValue) => {
    console.log(newValue, OldValue)
  },
  {
    immediate: true,
    deep: true
  }
)
//4.deep 深度监视,默认的watch  进行的是浅层监视
//const 数据ref1 =ref(简单类型)  可以直接监视
//const 数据ref2 =ref(复杂类型)  监视不到复杂类型内部数据的变化
const userInfo = ref({
  name: 'zs',
  age: 18
})
const setUserInfo = () => {
  // userInfo.value.age++
  userInfo.value.name = 'ls'
  // userInfo.value = { name: 'ls', age: 20 }   这个才能被浅层监视到
}
// watch(
//   userInfo,
//   (newValue) => {
//     console.log(newValue)
//   },
//   {
//     deep: true
//   }
// )
//5.对于对象中的属性的监视
watch(
  () => userInfo.value.age,
  (newValue, OldValue) => {
    console.log(newValue, OldValue)
  }
)
</script>

<template>
  <div>{{ count }}</div>
  <button @click="changeCount">改数字</button>
  <div>{{ nikename }}</div>
  <button @click="changeNikename">改昵称</button>
  <div>---------------------------------------------</div>
  <div>{{ userInfo }}</div>
  <button @click="setUserInfo">修改数据</button>
</template>
