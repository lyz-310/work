<script setup>
defineOptions({
  name: 'LoginIndex'
})
</script>
<template>
  <div>我是登录页</div>
</template>
