<script setup>
defineOptions({
  name: 'LegisterIndex'
})
</script>
<template>
  <div>我是注册页</div>
</template>
