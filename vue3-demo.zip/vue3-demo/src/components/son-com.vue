<script setup>
//父传子
//1.给子组件，，添加属性的方式传值
//2.在子组件内部，通过pros方式接收
//由于直接写了setup，所以无法直接配置pros选项
//所以此处需要借助编译器宏函数，接收子组件传递的数据
const pros = defineProps({
  car: String,
  money: Number
})
console.log(pros.car)
console.log(pros.money)
const emit = defineEmits(['changeMoney'])
const buy = () => {
  //需要emit触发事件
  emit('changeMoney', 5)
}
</script>
<template>
  <!-- 对于pros传递过来的数据，模板中可以直接使用 -->
  <div class="son">我是子组件---{{ car }}---{{ money }}</div>
  <button @click="buy">花钱</button>
</template>
<style scoped>
.son {
  border: 1px solid #000;
  padding: 30px;
}
</style>
