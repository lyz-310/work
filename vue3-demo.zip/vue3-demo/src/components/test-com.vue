<script setup>
const count = 999
const sayhi = () => {
  console.log('hello')
}
defineExpose({
  count,
  sayhi
})
</script>
<template>
  <div>我是用于测试的组件---{{ count }}</div>
</template>
