<script setup>
import bottomCom from './bottom-com.vue'
</script>
<template>
  <div>
    <h2>我是中间组件</h2>
    <bottomCom></bottomCom>
  </div>
</template>
