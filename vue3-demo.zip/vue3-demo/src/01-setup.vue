<!-- <script>
export default {
  setup() {
    console.log('setup函数')
    //数据
    const message = 'hello vue3'
    //函数
    const logMessage = () => {
      console.log(message)
    }
    return {
      message,
      logMessage
    }
  },
  beforeCreate() {
    console.log('beforeCreate')
  }
}
</script> -->

<script setup>
console.log('setup函数')
//数据
const message = 'hello vue3'
//函数
const logMessage = () => {
  console.log(message)
}
</script>
<template>
  <div>{{ message }}</div>
  <button @click="logMessage">按钮</button>
</template>
