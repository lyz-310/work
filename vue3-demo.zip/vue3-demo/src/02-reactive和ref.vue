<script setup>
//1.reactive语法
//接收一个对象类型的数据，返回一个响应式的对象
// import { reactive } from 'vue'
// const state = reactive({
//   count: 100
// })
// const setCount = () => {
//   state.count++
// }
//2.ref接收简单类型或复杂类型，返回一个响应式对象
//本质  是在原有的数据的基础 上，外层包了一层对象，包成了我们的复杂类型
//底层： 包成复杂类型之后，再借助 reactive  实现的响应式
//注意点：在脚本中访问数据，需要通过.value
//        在template中不需要加.value(帮我们扒了一层)
//推荐用 ref
import { ref } from 'vue'
const count = ref(0)
console.log(count.value)
const setCount = () => {
  count.value++
}
</script>

<template>
  <div>{{ count }}</div>
  <button @click="setCount">+1</button>
</template>
