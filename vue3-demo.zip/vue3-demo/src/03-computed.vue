<script setup>
import { computed, ref } from 'vue'
//声明数据
const list = ref([1, 2, 3, 4, 5, 6, 7])
//基于list  派生出一个计算属性，从list中过滤出大于2
const res = computed(() => {
  return list.value.filter((item) => item > 3)
})
//定义一个修改数组的方法
const addFn = () => {
  list.value.push(666)
}
// const res = computed(() => {
//   return 返回的数据
// })
</script>
<template>
  <div>{{ res.join(',') }}</div>
  <button @click="addFn">修改数组</button>
</template>
